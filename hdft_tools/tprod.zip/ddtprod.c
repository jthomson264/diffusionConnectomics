/* Simple wrapper function for building repop for different input types */
#include "mxInfo.h" /* for the type enum */
#define XDTYPE DOUBLE_DTYPE
#define YDTYPE DOUBLE_DTYPE
#include "tprod.c"
